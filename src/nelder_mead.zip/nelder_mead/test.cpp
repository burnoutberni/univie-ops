#include <iostream>
#include "point.hpp"

int main() {
    point b{1, 3};
    point g{4, 6};
    point w{6, 2};

    point n_g = b + ((g - b)/2);
    point n_w = b + ((w - b)/2);

    std::cout << "new g: " << n_g.format() << "\nnew w: " << n_w.format() << '\n';
}
